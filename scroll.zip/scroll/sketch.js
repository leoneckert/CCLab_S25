function setup() {
  let canvas = createCanvas(800, 500);
  canvas.parent("p5-canvas-container");
  
}

function draw() {
  background(220);

  // how much have we scrolled?
  let scrollPercent = (document.getElementById("scrollContainer").scrollTop) / (document.getElementById("scrollContainer").scrollHeight - height);
  console.log(scrollPercent);
  text("You scrolled " + scrollPercent*100 + "% of the way.", 50, 100)
  
  
  let angle = map(scrollPercent, 0 ,1, 0, 360*2);
  push();
  translate(width/2, height/2);
  rotate(radians(angle))
  rect(-50, -50, 100, 100)
  pop();

  
}


function mousePressed(){
  circle(mouseX, mouseY, 10)
}